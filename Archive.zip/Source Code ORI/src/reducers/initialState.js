export const filterState = {
    cats: [],
    locs: [],
    feas: [],
    tags: [],
    prices: [0,1000],
    nearby: 'off',
    address_lat: '',
    address_lng: '',
    distance: 10,
    orderby: 'date',
    layout: 'list',
    status: '',
};