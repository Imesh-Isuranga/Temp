export default {
	app_key: 'MTVkemkxcG9jOGptM3ZpZDJiMnlmaQXXX',

	url: 'https://yeroku.com',
	terms_page: 'https://yeroku.com/help-center/',
}

export const defaultLanguage = {
	code: 'en',
	rtl: false
}
export const defaultCurrency = 'USD';